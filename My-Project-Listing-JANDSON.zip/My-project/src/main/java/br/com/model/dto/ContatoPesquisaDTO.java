/**
 * 
 */
package br.com.model.dto;

/**
 * @author Jandson dos anjos
 *
 */
public class ContatoPesquisaDTO {

	private String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
